﻿/* (x, y) に色 c で点を打つ関数 (他で定義している) */
extern void point(int x, int y, const double *c);

/* 三角関数を使っているので数学ライブラリを使う */
#include <math.h>

/* 水平線を描く */
static void hline(int x0, int x1, int y, const double *c)
{
  /*
  ** (1) 以前作成した水平線を描く関数 hline() の中身をここに書く
  */
}

/* 三角形を描く*/
static void triangle(int x0, int y0, int x1, int y1, int x2, int y2, const double *c)
{
  /*
  ** (2) ここに hline() を使って３点 (x0, y0), (x1, y1), (x2, y2)
  **     を頂点とする三角形を色 c で塗りつぶすプログラムを書く
  */
}

/* triangle() を使って図形を描く */
void draw(int width, int height)
{
  /*
  ** (3) 以下を triangle() を使って自分で考えた図形を描くプログラムに書き換える
  **     （以下はサンプルなので，このままだったら0.5点減点する）
  **     引数 width と height は開いたウィンドウの幅と高さの画素数
  */

  /* ここから↓書き換える */
  static const double color[6][3] = { /* 色データ */
    { 0.0, 0.0, 1.0 },                /* 青　　　 */
    { 0.0, 1.0, 1.0 },                /* シアン　 */
    { 0.0, 1.0, 0.0 },                /* 緑　　　 */
    { 1.0, 1.0, 0.0 },                /* 黄　　　 */
    { 1.0, 0.0, 0.0 },                /* 緑　　　 */
    { 1.0, 0.0, 1.0 },                /* マゼンタ */
  };
  static int frame = 0;
  double t0 = 0.0125663706143591729538 * (double)frame;
  int x0 = width / 2, y0 = height / 2;
  int i;

  for (i = 0; i < 6; i++) {
    double t1 = t0 + 1.04719755119659774615 * (double)i;
    double t2 = t1 - 0.52359877559829887307;
    double t3 = t1 + 0.52359877559829887307;
    int x1 = (int)(height * 0.1 * cos(t1)) + x0;
    int y1 = (int)(height * 0.1 * sin(t1)) + y0;
    int x2 = (int)(height * 0.5 * cos(t2)) + x0;
    int y2 = (int)(height * 0.3 * sin(t2)) + y0;
    int x3 = (int)(height * 0.5 * cos(t3)) + x0;
    int y3 = (int)(height * 0.3 * sin(t3)) + y0;
    triangle(x1, y1, x2, y2, x3, y3, color[i]);
  }
  if (++frame >= 500) frame = 0;
  /* ここまで↑を書き換える */
}
