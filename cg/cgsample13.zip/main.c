﻿/*
** 三角形分割された Alias OBJ 形式の形状データを
** OpenGL/GLUT を使ってアニメーション表示するプログラム
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#if defined(WIN32)
#  pragma warning(disable:4819)
#  pragma warning(disable:4996)
//#  pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#  include "freeglut.h"
#elif defined(X11)
#  include <GL/freeglut.h>
#elif defined(__APPLE__)
#  include <GLUT/glut.h>
#else
#  error "This platform is not supported."
#endif

/* 頂点の最大数と三角形の最大数 */
#define MAXPOINTS 100000
#define MAXFACES  100000

/* 時刻 t における位置 p を求め，その時の方向を返す関数 */
extern void animate(double t, double p[], double r[]);

/* データファイル名 */
static const char data[] = "data.dat";

/* 頂点の数と三角形の数 */
static int nv = 0, nf = 0;

/* 頂点データと三角形データ */
static GLfloat position[MAXPOINTS][3];
static GLfloat normal[MAXPOINTS][3];
static GLuint face[MAXFACES][3];
static GLfloat fnormal[MAXFACES][3];

/*
** Catmull-Rom Spline
*/
static double catmull_rom(double x0, double x1, double x2, double x3, double t)
{
  double v1 = (x2 - x0) * 0.5f, v2 = (x3 - x1) * 0.5f;

  return (((2.0f * x1 - 2.0f * x2 + v1 + v2) * t
    - 3.0f * x1 + 3.0f * x2 - 2.0f * v1 - v2) * t
    + v1) * t + x1;
}

/*
** Catmull-Rom Spline による点列の補間
*/
static void interpolate(double *p, const double *p0, const double *p1, const double *p2, const double *p3, double t)
{
  p[0] = catmull_rom(p0[0], p1[0], p2[0], p3[0], t);
  p[1] = catmull_rom(p0[1], p1[1], p2[1], p3[1], t);
  p[2] = catmull_rom(p0[2], p1[2], p2[2], p3[2], t);
}

/*
** 任意の数の点列の Catmull-Rom Spline による補間
**   p: 補間する点列の座標値
**   t: 補間する点列のタイムライン（値は昇順に格納されている）
**   n: 点の数
**   u: 補間値を得るパラメータ (t[0]≦u≦t[n - 1]）
*/
void curve(double q[3], const double p[][3], const double *t, int n, double u)
{
  if (--n < 0)
    return;
  else if (n == 0)
  {
    q[0] = p[0][0];
    q[1] = p[0][1];
    q[2] = p[0][2];
  }
  else {
    int i = 0, j = n;
    
    // u を含む t の区間 [t[i], t[i+1]) を二分法で求める
    while (i < j)
    {
      int k = (i + j) / 2;
      if (t[k] < u)
        i = k + 1;
      else
        j = k;
    }
    
    if (--i < 0) i = 0;
    if (i < n)
    {
      int i0 = i - 1;
      int i1 = i + 1;
      int i2 = i1 + 1;

      if (i0 < 0) i0 = 0;
      if (i2 > n) i2 = n;
      
#if 0
      // タイムラインもスプライン補間する場合
      interpolate(q, p[i0], p[i], p[i1], p[i2],
        catmull_rom(t[i0], t[i], t[i1], t[i2], (u - t[i]) / (t[i1] - t[i])) - t[i]);
#else
      // タイムラインは線形（折れ線）補間する場合
      interpolate(q, p[i0], p[i], p[i1], p[i2], (u - t[i]) / (t[i1] - t[i]));
#endif
    }
    else {
      q[0] = p[n][0];
      q[1] = p[n][1];
      q[2] = p[n][2];
    }
  }
}

/*
** データファイルの読み込み
*/
static int loadFile(const char *name)
{
  FILE *fp = fopen(name, "r");
  char buf[1024];

  if (fp == NULL)
  {
    perror(name);
    return 1;
  }

  while (fgets(buf, sizeof buf, fp))
  {
    if (buf[0] == 'v' && buf[1] == ' ')
    {
      if (nv >= MAXPOINTS)
      {
        fprintf(stderr, "点の数が多すぎます\n");
        return 1;
      }
      sscanf(buf, "%*s %f %f %f", &position[nv][0], &position[nv][1], &position[nv][2]);
      ++nv;
    }
    else if (buf[0] == 'f' && buf[1] == ' ')
    {
      int v0, v1, v2;

      if (nf >= MAXFACES)
      {
        fprintf(stderr, "面の数が多すぎます\n");
        return 1;
      }
      if (sscanf(buf + 2, "%d/%*d/%*d %d/%*d/%*d %d/%*d/%*d", &v0, &v1, &v2) != 3)
      {
        if (sscanf(buf + 2, "%d//%*d %d//%*d %d//%*d", &v0, &v1, &v2) != 3)
        {
          if (sscanf(buf + 2, "%d %d %d", &v0, &v1, &v2) != 3)
          {
            fprintf(stderr, "面データが読めません\n");
            return 1;
          }
        }
      }
      face[nf][0] = v0 - 1;
      face[nf][1] = v1 - 1;
      face[nf][2] = v2 - 1;
      ++nf;
    }
  }

  return 0;
}

/*
** 面法線ベクトルの算出
*/
static void faceNormal(GLfloat fn[][3], GLfloat p[][3], GLuint f[][3], int nf)
{
  int i;

  for (i = 0; i < nf; ++i)
  {
    int v0 = f[i][0], v1 = f[i][1], v2 = f[i][2];
    float dx1 = p[v1][0] - p[v0][0];
    float dy1 = p[v1][1] - p[v0][1];
    float dz1 = p[v1][2] - p[v0][2];
    float dx2 = p[v2][0] - p[v0][0];
    float dy2 = p[v2][1] - p[v0][1];
    float dz2 = p[v2][2] - p[v0][2];

    fn[i][0] = dy1 * dz2 - dz1 * dy2;
    fn[i][1] = dz1 * dx2 - dx1 * dz2;
    fn[i][2] = dx1 * dy2 - dy1 * dx2;
  }
}

/*
** 頂点の仮想法線ベクトルの算出
*/
static void vertexNormal(GLfloat vn[][3], int nv, GLfloat fn[][3], GLuint f[][3], int nf)
{
  int i;
  
  for (i = 0; i < nv; ++i)
  {
    vn[i][0] = vn[i][1] = vn[i][2] = 0.0f;
  }
  
  for (i = 0; i < nf; ++i)
  {
    int v0 = f[i][0], v1 = f[i][1], v2 = f[i][2];

    vn[v0][0] += fn[i][0];
    vn[v0][1] += fn[i][1];
    vn[v0][2] += fn[i][2];

    vn[v1][0] += fn[i][0];
    vn[v1][1] += fn[i][1];
    vn[v1][2] += fn[i][2];

    vn[v2][0] += fn[i][0];
    vn[v2][1] += fn[i][1];
    vn[v2][2] += fn[i][2];
  }

  for (i = 0; i < nv; ++i)
  {
    float a = sqrtf(vn[i][0] * vn[i][0]
                  + vn[i][1] * vn[i][1]
                  + vn[i][2] * vn[i][2]);

    if (a != 0.0f)
    {
      vn[i][0] /= a;
      vn[i][1] /= a;
      vn[i][2] /= a;
    }
  }
}

/*
** 画面表示
*/
static void display(void)
{
  static const GLfloat upNormal[] =
  {
    0.0f, 1.0f, 0.0f,
    0.0f, 1.0f, 0.0f,
    0.0f, 1.0f, 0.0f,
    0.0f, 1.0f, 0.0f,
  };
  static const GLfloat roadColor[] = { 0.2f, 0.2f, 0.2f, 1.0f };
  static const GLfloat roadShape[] =
  {
    -9.0f, 0.0f, 130.0f,
     3.0f, 0.0f, 130.0f,
     3.0f, 0.0f, -30.0f,
    -9.0f, 0.0f, -30.0f,
  };
  static GLfloat lineColor[] = { 0.9f, 0.9f, 0.2f, 1.0f };
  static GLfloat lineShape[] =
  {
    -3.2f, 0.0f,  1.25f,
    -2.8f, 0.0f,  1.25f,
    -2.8f, 0.0f, -1.25f,
    -3.2f, 0.0f, -1.25f,
  };
  static GLfloat bodyColor[] = { 0.9f, 0.2f, 0.2f, 1.0f };
  static GLfloat lightPosition[] = { 1.0f, 0.8f, 0.6f, 0.0f };
  double t = (glutGet(GLUT_ELAPSED_TIME) % 2000) / 1999.0, p[3], r[3];
  int i;

  /* 画面クリア */
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  /* 視点の設定 */
  glLoadIdentity();
  gluLookAt(100.0, 50.0, 150.0, 0.0, 0.0, 70.0, 0.0, 1.0, 0.0);

  /* 光源位置の設定 */
  glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);

  /* 道路は隠面消去せずに描く */
  glDisable(GL_DEPTH_TEST);

  /* 路面 */
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, roadColor);
  glVertexPointer(3, GL_FLOAT, 0, roadShape);
  glNormalPointer(GL_FLOAT, 0, upNormal);
  glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

  /* センターライン*/
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, lineColor);
  glVertexPointer(3, GL_FLOAT, 0, lineShape);
  glNormalPointer(GL_FLOAT, 0, upNormal);
  for (i = -25; i <= 125; i += 5)
  {
    glPushMatrix();
    glTranslated(0.0, 0.0, (double)i);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    glPopMatrix();
  }

  /* 車は隠面消去して描く */
  glEnable(GL_DEPTH_TEST);

  /* 車の方向と位置 */
  animate(t, p, r);
  glTranslated(p[0], p[1], p[2]);
  glRotated(r[0], 0.0, 1.0, 0.0);
  glRotated(r[1], 1.0, 0.0, 0.0);
  glRotated(r[2], 0.0, 0.0, 1.0);

  /* 車 */
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, bodyColor);
  glVertexPointer(3, GL_FLOAT, 0, position);
  glNormalPointer(GL_FLOAT, 0, normal);
  glDrawElements(GL_TRIANGLES, nf * 3, GL_UNSIGNED_INT, face);

  glutSwapBuffers();
}

/*
** resise() でウィンドウの幅と高さを得る
** ウィンドウの座標系をビューポート（出力画像）と一致させる
*/
static void resize(int w, int h)
{
  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(30.0, (double)w / (double)h, 100, 220.0);
  glMatrixMode(GL_MODELVIEW);
}

/*
** アニメーション
*/
static void idle(void)
{
  glutPostRedisplay();
}

/*
** キー操作
*/
static void keyboard(unsigned char key, int x, int y)
{
  static int animation = 0;

  switch (key)
  {
  case 'q':
  case 'Q':
  case '\033':
    /* q, Q, ESC キーで終了する */
    exit(0);
  case 'g':
  case 'G':
    /* g, G キーでアニメーションを開始／停止する */
    animation = 1 - animation;
    if (animation != 0)
      glutIdleFunc(idle);
    else
      glutIdleFunc(0);
    break;
  default:
    /* その他のキーでアニメーションを１フレームだけ進める */
    glutPostRedisplay();
    break;
  }
}

/*
** 初期化
*/
static void init()
{
  loadFile(data);
  faceNormal(fnormal, position, face, nf);
  vertexNormal(normal, nv, fnormal, face, nf);
  glClearColor(1.0, 1.0, 1.0, 0.0);
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_NORMAL_ARRAY);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
}

/*
** glut/OpenGL の初期化と実行
*/
int main(int argc, char *argv[])
{
  glutInit(&argc, argv);
  glutInitWindowSize(320, 240);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
#if !defined(__APPLE__)
  glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
#endif
  glutCreateWindow("CG sample");
  glutDisplayFunc(display);
  glutReshapeFunc(resize);
  glutKeyboardFunc(keyboard);
  init();
  glutGet(GLUT_ELAPSED_TIME);
  glutMainLoop();
  return 0;
}
