﻿/*
** 任意の数の点列の Catmull-Rom Spline による補間
**   p:   補間した値（３要素の配列）
**   val: 補間する点列の座標値（３要素の配列の配列）
**   key: 補間する点列の個々の点における時刻（タイムライン，値は昇順に格納されている必要がある）
**   n:   点の数
**   t:   補間値を得るパラメータ (key[0]≦t≦key[n - 1]）
** ※この関数を使うかどうかは任意
*/
extern void curve(double p[3], const double val[][3], const double key[], int n, double t);


/* 時刻 t における位置 p, 方向 r を求める */
void animate(double t, double p[], double r[])
{
  p[0] = 0.0;
  p[1] = 0.0;
  p[2] = 0.0;
  r[0] = 0.0;
  r[1] = 0.0;
  r[2] = 0.0;
}
