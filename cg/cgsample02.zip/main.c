﻿/*
** OpenGL/GLUT を使って点を打つプログラム
** 図形を描く draw() を point() を使って作成し，
** それをこのプログラムとリンクする
*/

#include <stdlib.h>
#if defined(WIN32)
#  pragma warning(disable:4819)
//#  pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#  include "glut.h"
#elif defined(X11)
#  include <GL/glut.h>
#elif defined(__APPLE__)
#  include <GLUT/glut.h>
#else
#  error "This platform is not supported."
#endif

/*
** 与えられた領域を実際にレンダリングする関数
** point() を使って外部関数として定義する
** 引数はウィンドウの幅と高さ
*/
extern void draw(int, int);

/*
** 点 (x, y) に色 c で点を打つ
** trace() で使用する
*/
void point(int x, int y, const double *c)
{
  glColor3dv(c);
  glVertex2i(x, y);
}

/* 開いたウィンドウのサイズ */
static int width, height;

/*
** glut を用いた表示プログラム
** display() 内で trace() を呼び出している
*/
static void display(void)
{
  glClear(GL_COLOR_BUFFER_BIT);
  glBegin(GL_POINTS);
  draw(width, height);
  glEnd();
  glFlush();
}

/*
** resise() でウィンドウの幅と高さを得る
** ウィンドウの座標系をビューポート（出力画像）と一致させる
*/
static void resize(int w, int h)
{
  glViewport(0, 0, width = w, height = h);
  glLoadIdentity();
  glOrtho(-0.5, (GLdouble)w - 0.5, -0.5, (GLdouble)h - 0.5, -1.0, 1.0);
}

/*
** q, Q, ESC キーで終了する
*/
static void keyboard(unsigned char key, int x, int y)
{
  switch (key)
  {
  case 'q':
  case 'Q':
  case '\033':
    exit(0);
  default:
    break;
  }
}

/*
** 初期化
*/
static void init(void)
{
  glClearColor(1.0, 1.0, 1.0, 0.0);
}

/*
** glut/OpenGL の初期化と実行
*/
int main(int argc, char *argv[])
{
  glutInit(&argc, argv);
  glutInitWindowSize(320, 240);
  glutInitDisplayMode(GLUT_RGB);
  glutCreateWindow("CG sample");
  glutKeyboardFunc(keyboard);
  glutReshapeFunc(resize);
  glutDisplayFunc(display);
  init();
  glutMainLoop();
  return 0;
}
