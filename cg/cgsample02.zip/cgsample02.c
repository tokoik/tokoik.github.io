﻿/* (x, y) に色 c で点を打つ関数 (他で定義している) */
extern void point(int x, int y, const double *c);

/* 水平線を描く */
static void hline(int x0, int x1, int y, const double *c)
{
  /*
  ** (1) ここに point() を使って２点 (x0, y), (x1, y) を結ぶ
  **     線分を色 c で描くプログラムを書く
  */
}

/* 矩形領域を単色で塗りつぶす */
static void fill(int xa, int ya, int xb, int yb, const double *c)
{
  /*
  ** (2) ここに hline() を使って２点 (xa, ya), (xb, yb) を結ぶ
  **     線分を対角線とする矩形領域を色 c で塗りつぶすプログラムを書く
  */
}

/* 図形を描く */
void draw(int width, int height)
{
  /*
  ** (3) ここに fill() を使って図形を描くプログラムを書く
  **     引数 width と height は開いたウィンドウの幅と高さの画素数
  */
}
