﻿#if defined(WIN32)
#  pragma warning(disable:4819)
#endif
#include <math.h>

/*
** データの引き渡し
*/
extern void storage(const void *, int, int, int);

/*
** 空間の分割数
*/
#define XSLICES 7
#define YSLICES 7
#define ZSLICES 7

/*
** 空間格子の配列に形状データを設定する
*/
void shape(void)
{
  /*
  ** メモリの確保
  */
  static unsigned char volume[ZSLICES][YSLICES][XSLICES];
  storage(volume, XSLICES, YSLICES, ZSLICES);
  
  /*
  ** 以下を書き換えてください
  */
  volume[3][3][2] = 5;
  volume[3][3][4] = 2;
}
