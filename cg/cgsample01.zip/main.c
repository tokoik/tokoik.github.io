﻿#include <math.h>
#include <stdlib.h>
#if defined(WIN32)
#  pragma warning(disable:4819)
//#  pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#  include "glut.h"
#elif defined(X11)
#  include <GL/glut.h>
#elif defined(__APPLE__)
#  include <GLUT/glut.h>
#else
#  error "This platform is not supported."
#endif

/* 光源の位置 */
static GLfloat pos[] = { 0.0f, 0.0f, 1.0f, 0.0f };

/* 視点の位置 */
static GLdouble ex = 2.0, ey = 3.0, ez = 4.0;

/* 表示図形のディスプレイリスト番号 */
static GLuint obj;

/* マウス移動量のスケール */
static double sx, sy;

/* ドラッグ開始位置 */
static int cx, cy;

/* 回転の初期値とドラッグ中の回転 (クォータニオン) */
static double cq[4] = { 0.0, 0.0, 0.0, 1.0 };
static double tq[4];

/* 回転の変換行列 */
static double rt[16];

/* メモリ空間 */
static unsigned char *memory;

/* メモリ空間の分割数 */
static int xslices, yslices, zslices;

/*
** クォータニオンの積 r <- p x q
*/
static void qmul(double *r, const double *p, const double *q)
{
  r[0] = p[1] * q[2] - p[2] * q[1] + p[0] * q[3] + p[3] * q[0];
  r[1] = p[2] * q[0] - p[0] * q[2] + p[1] * q[3] + p[3] * q[1];
  r[2] = p[0] * q[1] - p[1] * q[0] + p[2] * q[3] + p[3] * q[2];
  r[3] = p[3] * q[3] - p[0] * q[0] - p[1] * q[1] - p[2] * q[2];
}

/*
** 回転の変換行列 r <- クォータニオン q
*/
static void qrot(double *m, const double *q)
{
  double xx = q[0] * q[0] * 2.0;
  double yy = q[1] * q[1] * 2.0;
  double zz = q[2] * q[2] * 2.0;
  double xy = q[0] * q[1] * 2.0;
  double yz = q[1] * q[2] * 2.0;
  double zx = q[2] * q[0] * 2.0;
  double xw = q[0] * q[3] * 2.0;
  double yw = q[1] * q[3] * 2.0;
  double zw = q[2] * q[3] * 2.0;
  
  m[ 0] = 1.0 - yy - zz;
  m[ 1] = xy + zw;
  m[ 2] = zx - yw;
  m[ 4] = xy - zw;
  m[ 5] = 1.0 - zz - xx;
  m[ 6] = yz + xw;
  m[ 8] = zx + yw;
  m[ 9] = yz - xw;
  m[10] = 1.0 - xx - yy;
  m[ 3] = m[ 7] = m[11] = m[12] = m[13] = m[14] = 0.0;
  m[15] = 1.0;
}

static void display(void)
{
  /* 画面クリア */
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  /* モデルビュー変換行列の初期化 */
  glLoadIdentity();

  /* 光源の位置を設定 */
  glLightfv(GL_LIGHT0, GL_POSITION, pos);
  
  /* 視点の移動 */
  gluLookAt(ex, ey, ez, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
  
  /* 回転 */
  glMultMatrixd(rt);

  /* 描画 */
  glCallList(obj);

  glutSwapBuffers();
}

static void resize(int w, int h)
{
  /* マウスポインタ位置のウィンドウ内の相対的位置への換算用 */
  sx = 1.0 / (double)w;
  sy = 1.0 / (double)h;

  /* ウィンドウ全体をビューポートにする */
  glViewport(0, 0, w, h);

  /* 透視変換行列の指定 */
  glMatrixMode(GL_PROJECTION);

  /* 透視変換行列の初期化 */
  glLoadIdentity();
  gluPerspective(30.0, (double)w / (double)h, 1.0, 100.0);

  /* モデルビュー変換行列の指定 */
  glMatrixMode(GL_MODELVIEW);
}

static void idle(void)
{
  glutPostRedisplay();
}

static void mouse(int button, int state, int x, int y)
{
  switch (button) {
  case GLUT_LEFT_BUTTON:
    if (state == GLUT_DOWN) {
      /* ドラッグ開始点位置を記録する */
      cx = x;
      cy = y;
      /* アニメーション開始 */
      glutIdleFunc(idle);
    }
    else {
      /* クォータニオンのノルム */
      double a = sqrt(tq[0] * tq[0] + tq[1] * tq[1] + tq[2] * tq[2] + tq[3] * tq[3]);
      /* ドラッグ終了時の回転を保存する */
      cq[0] = tq[0] / a;
      cq[1] = tq[1] / a;
      cq[2] = tq[2] / a;
      cq[3] = tq[3] / a;
      /* アニメーション終了 */
      glutIdleFunc(0);
    }
    break;
  default:
    break;
  }
}

static void motion(int x, int y)
{
  /* マウスポインタの位置のドラッグ開始位置からの変位 (相対値) */
  double dx = (x - cx) * sx;
  double dy = (y - cy) * sy;
  
  /* マウスポインタの位置のドラッグ開始位置からの距離 (相対値) */
  double a = sqrt(dx * dx + dy * dy);
  
  if (a != 0.0) {
    /* マウスのドラッグに伴う回転のクォータニオン dq を求める */
    double ar = a * 3.14159265358979323846;
    double as = sin(ar) / a;
    double dq[4] = { dy * as, dx * as, 0.0, cos(ar) };
    
    /* 回転の初期値 cq に dq を掛けて回転を合成する */
    qmul(tq, dq, cq);

    /* クォータニオンから回転の変換行列を求める */
    qrot(rt, tq);
  }
}

static void keyboard(unsigned char key, int x, int y)
{
  switch (key) {
  case 'q':
  case 'Q':
  case '\033':
    /* q, Q, ESC をタイプしたら終了 */
    exit(0);
  case 'x':
    ex += 0.5;
    break;
  case 'X':
    ex -= 0.5;
    break;
  case 'y':
    ey += 0.5;
    break;
  case 'Y':
    ey -= 0.5;
    break;
  case 'z':
    ez += 0.5;
    break;
  case 'Z':
    ez -= 0.5;
    break;
  default:
    break;
  }
  glutPostRedisplay();
}

static void init(void)
{
  /* 回転行列の初期化 */
  qrot(rt, cq);

  /* 初期設定 */
  glClearColor(1.0, 1.0, 1.0, 1.0);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
  glEnable(GL_COLOR_MATERIAL);
}

static void scene(void)
{
  extern void shape(void);
  
  static const GLdouble vertex[][3] = {
    { 0.0, 0.0, 0.0 },
    { 2.0, 0.0, 0.0 },
    { 2.0, 2.0, 0.0 },
    { 0.0, 2.0, 0.0 },
    { 0.0, 0.0, 2.0 },
    { 2.0, 0.0, 2.0 },
    { 2.0, 2.0, 2.0 },
    { 0.0, 2.0, 2.0 }
  };

  static const int face[][4] = {
    { 3, 2, 1, 0 },
    { 2, 6, 5, 1 },
    { 6, 7, 4, 5 },
    { 7, 3, 0, 4 },
    { 0, 1, 5, 4 },
    { 7, 6, 2, 3 }
  };

  static const int normal[][3] = {
    {  0,  0, -1 },
    {  1,  0,  0 },
    {  0,  0,  1 },
    { -1,  0,  0 },
    {  0, -1,  0 },
    {  0,  1,  0 }
  };

  static GLfloat d[][4] = {
    { 0.1f, 0.1f, 0.1f },
    { 0.9f, 0.1f, 0.1f },
    { 0.1f, 0.9f, 0.1f },
    { 0.9f, 0.9f, 0.1f },
    { 0.1f, 0.1f, 0.9f },
    { 0.9f, 0.1f, 0.9f },
    { 0.1f, 0.9f, 0.9f },
    { 0.9f, 0.9f, 0.9f },
  };

  int i, j, k, l, m;

  /* ボクセルデータの作成 */
  shape();

  /* 表示図形をディスプレイリストに登録 */
  obj = glGenLists(1);

  /* 立方体 */
  glNewList(obj, GL_COMPILE);
  glBegin(GL_QUADS);
  for (k = 0; k < zslices; ++k)
  {
    double z = (double)(k * 2 - zslices) / (double)zslices;
    for (j = 0; j < yslices; ++j) {
      double y = (double)(j * 2 - yslices) / (double)yslices;
      for (i = 0; i < xslices; ++i) {
        double x = (double)(i * 2 - xslices) / (double)xslices;
        unsigned char n = memory[((k * yslices) + j) * xslices + i];
        if (n > 0) {
          glColor3fv(d[(n - 1) & 7]);
          for (m = 0; m < 6; m++) {
            int in = i + normal[m][0];
            int jn = j + normal[m][1];
            int kn = k + normal[m][2];

            /* 境界面だけを描く */
            if (in < 0 || in >= xslices ||
                jn < 0 || jn >= yslices ||
                kn < 0 || kn >= zslices ||
                !memory[(kn * yslices + jn) * xslices + in]) {
              glNormal3d((double)normal[m][0], (double)normal[m][1], (double)normal[m][2]);
              for (l = 0; l < 4; l++) {
                double px = x + vertex[face[m][l]][0] / (double)xslices;
                double py = y + vertex[face[m][l]][1] / (double)yslices;
                double pz = z + vertex[face[m][l]][2] / (double)zslices;
                
                glVertex3d(px, py, pz);
              }
            }
          }
        }
      }
    }
  }
  glEnd();
  glEndList();
}

void storage(const void *m, int xs, int ys, int zs)
{
  memory = (unsigned char *)m;
  xslices = xs;
  yslices = ys;
  zslices = zs;
}

int main(int argc, char *argv[])
{
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
  glutCreateWindow("CG sample");
  glutDisplayFunc(display);
  glutReshapeFunc(resize);
  glutMouseFunc(mouse);
  glutMotionFunc(motion);
  glutKeyboardFunc(keyboard);
  init();
  scene();
  glutMainLoop();
  return 0;
}
