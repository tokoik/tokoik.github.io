﻿/* (x, y) に色 c で点を打つ関数 (他で定義している) */
extern void point(int x, int y, const double *c);

/* 数学ライブラリは多分使うと思う */
#include <math.h>

/* 線分を描く */
static void line(int x0, int y0, int x1, int y1, const double *c)
{
  /*
  ** (1) 第３回の宿題で作成した線分を描く関数 line() の中身をここに書く
  */
}

/* p0～p3 を制御点とするベジェ曲線の折れ線近似を色 c で描く */
static void bezier(const double *p0, const double *p1,
  const double *p2, const double *p3, const double *c)
{
  static const int STEP = 20; /* ベジェ曲線の分割数 */
  /*
  ** (2) ここに line() を使って４点 p0, p1, p2, p3 を制御点とする
  **     ベジェ曲線の折れ線近似を色 c で描くプログラムを書く
  */
}

/* bezier() を使って図形を描く */
void draw(int width, int height)
{
  /*
  ** (3) 以下を bezier() を使って自分で考えた図形を描くプログラムに書き換える
  **     （以下はサンプルなので，これに類似していれば減点）
  **     引数 width と height は開いたウィンドウの幅と高さの画素数
  */

  /* ここから↓書き換える */
  static int frame = 0;
  const double s = sin(((frame++) & 0xff) * 0.02464) * 0.4 + 0.4;
  const double cx = (double)width * 0.5;    /* ウィンドウの中心のｘ座標置 */
  const double cy = (double)height * 0.5;   /* ウィンドウの中心のｙ座標置 */
  const double ox = cx * s;                 /* 制御点の移動量　　　　　　 */
  const double p[2][4][2] =                 /* 制御点データ　　　　　　　 */
  {
    {
      {  0.0 * cx + cx, -0.6 * cy + cy },
      {  0.8 * cx + cx, -0.2 * cy + cy },
      {  0.8 * cx + cx,  0.8 * cy + cy },
      {  0.0 * cx + cx + ox,  0.4 * cy + cy },
    },
    {
      {  0.0 * cx + cx, -0.6 * cy + cy },
      { -0.8 * cx + cx, -0.2 * cy + cy },
      { -0.8 * cx + cx,  0.8 * cy + cy },
      {  0.0 * cx + cx - ox,  0.4 * cy + cy },
    },
  };
  static const double c[2][3] =       /* 色データ　　　　　　　　　 */
  {
    { 1.0, 0.3, 0.1 },
    { 0.1, 0.3, 1.0 },
  };
  
  int i;
  
  for (i = 0; i < 2; ++i) bezier(p[i][0], p[i][1], p[i][2], p[i][3], c[i]);
  /* ここまで↑を書き換える */
}
