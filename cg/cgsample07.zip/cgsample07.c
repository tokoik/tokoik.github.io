﻿/* 数学ライブラリは多分使うと思う */
#include <math.h>

/* (x, y) に色 c で点を打つ関数 (他で定義している) */
extern void point(int, int, const double *);

/* ウィンドウサイズを変更する (他で定義している) */
extern void size(int, int);

/* 背景色 (デフォルトは白) を変更する (他で定義している) */
extern void background(double, double, double);

/* 画面を消去する (他で定義している) */
extern void clear(void);

/* 直前にタイプしたキーの文字を得る (他で定義している) */
extern unsigned char getkey(void);

/* ←:100 ↑:101 →:102 ↓:103 を返す (他で定義している) */
extern int getspecial(void);

/* 経過時間を ms で返す (他で定義している) */
extern int elapsed(void);

/* 描画前の初期設定 */
void setup(void)
{
  /*
  ** ここは最初に draw() を実行する前に一度だけ実行される
  ** 背景色の変更など描画前に行いたい処理があればここに書く
  */
}

/* 線分を描く */
static void line(int x0, int y0, int x1, int y1, const double *c)
{
  /*
  ** (1) 以前作成した線分を描く関数 line() の中身をここに書く
  */
}

/*
** 座標変換：ベクトル v2 ← ベクトル v1 に行列 m を掛けた結果
*/
static void transform(double v2[], double m[][4], double v1[])
{
  int j;

  for (j = 0; j < 4; ++j)
  {
    v2[j] = m[j][0] * v1[0]
      + m[j][1] * v1[1]
      + m[j][2] * v1[2]
      + m[j][3] * v1[3];
  }
}

/*
** 行列の積：行列 m3 ← 行列 m1 と行列 m2 の積
*/
static void multiply(double m3[][4], double m1[][4], double m2[][4])
{
  int k;

  for (k = 0; k < 4; ++k)
  {
    int j;

    for (j = 0; j < 4; ++j)
    {
      m3[k][j] = m1[k][0] * m2[0][j]
        + m1[k][1] * m2[1][j]
        + m1[k][2] * m2[2][j]
        + m1[k][3] * m2[3][j];
    }
  }
}

/*
** 平行移動：行列 m ← (x, y, z) に平行移動する変換行列
*/
static void setTranslation(double m[][4], double x, double y, double z)
{
  /*
  ** (2) ４×４要素の配列 m の個々の要素に値を設定するプログラムを書く
  */
}

/*
** 拡大縮小：行列 m ← 原点中心に (a, b, c) 倍する変換行列
*/
static void setScale(double m[][4], double a, double b, double c)
{
  /*
  ** (3) ４×４要素の配列 m の個々の要素に値を設定するプログラムを書く
  */
}

#define PI 3.14159265358979323846                       /* 円周率π */

/*
** x 軸中心の回転：行列 m ← x 軸を中心にして angle 度回転する変換行列
*/
static void setRotationX(double m[][4], double angle)
{
  /*
  ** (4) ４×４要素の配列 m の個々の要素に X 軸中心の回転行列の値を設定する
  */
}

/*
** y 軸中心の回転：行列 m ← y 軸を中心にして angle 度回転する変換行列
*/
static void setRotationY(double m[][4], double angle)
{
  /*
  ** (5) ４×４要素の配列 m の個々の要素に Y 軸中心の回転行列の値を設定する
  */
}

/*
** z 軸中心の回転：行列 m ← z 軸を中心にして angle 度回転する変換行列
*/
static void setRotationZ(double m[][4], double angle)
{
  /*
  ** (6) ４×４要素の配列 m の個々の要素に Z 軸中心の回転行列の値を設定する
  */
}

/*
** 投影によって画面上の座標値を求める
**     v: 座標値の配列 (頂点表), m: 変換行列
**     s: 画面上の座標値の配列, n: 座標数（頂点数）
*/
static void project(double s[][4], double m[][4], double v[][4], int n)
{
  /*
  ** (7) 引数 v で与えられた n 個の４要素の配列（２次元配列）の
  **     個々の要素を引数 m で与えられた４×４要素の配列（変換行列）
  **     で座標変換し，引数 s で与えられた配列の各要素に格納する
  */
}

/*
** ワイヤーフレームの描画（稜線表の稜線を v に与えられた座標値で描画）
**     s: 画面上の座標値, e: 稜線表, ne: 稜線数
*/
static void wireframe(double s[][4], int e[][2], int ne)
{
  static const double black[] = { 0.0, 0.0, 0.0 };
  int i;

  for (i = 0; i < ne; ++i)
  {
    /* 線分の端点の番号を取り出す */
    int v0 = e[i][0], v1 = e[i][1];

    /* 端点の座標を整数化する */
    int x0 = (int)(s[v0][0] + 0.5);
    int y0 = (int)(s[v0][1] + 0.5);
    int x1 = (int)(s[v1][0] + 0.5);
    int y1 = (int)(s[v1][1] + 0.5);

    line(x0, y0, x1, y1, black);
  }
}

/* 頂点の座標値（頂点表のデータ） */
static double vertex[][4] =
{
  /*
  ** (8) 頂点表のデータ (同次座標) をここに書く
  */
  {  0.0,  6.0,  2.0,  1.0 }, /* 頂点 a */
  {  4.0,  2.0,  2.0,  1.0 }, /* 頂点 b */
  { -4.0,  2.0,  2.0,  1.0 }, /* 頂点 c */
  {  0.0,  6.0, -2.0,  1.0 }, /* 頂点 d */
  {  4.0,  2.0, -2.0,  1.0 }, /* 頂点 e */
  { -4.0,  2.0, -2.0,  1.0 }, /* 頂点 f */
  {  0.0,  4.0,  0.0,  1.0 }, /* 頂点 g */
};

/* 線分の端点番号（稜線表のデータ） */
static int edge[][2] =
{
  /*
  ** (9) 稜線表のデータをここに書く
  */
  { 0, 1 }, /* 稜線ア (a-b) */
  { 1, 2 }, /* 稜線イ (b-c) */
  { 2, 0 }, /* 稜線ウ (c-a) */
  { 5, 4 }, /* 稜線エ (f-e) */
  { 4, 3 }, /* 稜線オ (e-d) */
  { 3, 5 }, /* 稜線カ (d-f) */
  { 0, 6 }, /* 稜線キ (a-g) */
  { 1, 6 }, /* 稜線ク (b-g) */
  { 2, 6 }, /* 稜線ケ (c-g) */
  { 3, 6 }, /* 稜線コ (d-g) */
  { 4, 6 }, /* 稜線サ (e-g) */
  { 5, 6 }, /* 稜線シ (f-g) */
  { 1, 4 }, /* 稜線ス (b-e) */
  { 2, 5 }, /* 稜線セ (c-f) */
};

#define NVERTEX (sizeof vertex / sizeof vertex[0])      /* 頂点の数 */
#define NEDGE (sizeof edge / sizeof edge[0])            /* 稜線の数 */

/* 画面上の座標 */
static double screen[NVERTEX][4];

/*
** 図形の描画
*/
void draw(int width, int height)
{
  double scale[4][4];                       /* 拡大縮小の変換行列　 */
  double rotation[4][4];                    /* 物体の回転の変換行列 */
  double translation[4][4];                 /* 平行移動の変換行列　 */
  double viewport[4][4];                    /* ビューポート変換行列 */
  double matrix[4][4];                      /* 合成した変換行列　　 */

  /* 図形がウィンドウからはみ出ないようにするための倍率 */
  const double s = (width < height ? width : height) * 0.08;

  /* 図形を回転させるための回転角 */
  const double r = (elapsed() % 6000) * 0.06;

  /*
  ** ビューポート変換行列を求める
  */

  /* scale にウィンドウサイズにあわせて図形を拡大縮小する変換行列を求める */
  setScale(scale, s, s, 1.0);
  /* translation に図形がウィンドウに収まるように平行移動する変換行列を求める */
  setTranslation(translation, width * 0.5, height * 0.5, 0.0);
  /* 拡大縮小の変換行列に平行移動の変換行列を掛けてビューポート変換行列を求める */
  multiply(viewport, translation, scale);

  /*
  ** 一つ目の図形のモデル変換行列を求める
  */

  /* rotation に図形を Z 軸中心に r+90 度回転する変換行列を求める */
  setRotationZ(rotation, r + 90.0);

  /*
  ** 一つ目の図形の座標変換と描画
  */

  /* 回転の変換行列にビューポート変換行列を掛ける */
  multiply(matrix, viewport, rotation);
  /* 画面上の点の位置を求める */
  project(screen, matrix, vertex, NVERTEX);
  /* 求めた画面上の点の位置を使ってワイヤーフレームで図形を描く */
  wireframe(screen, edge, NEDGE);

  /*
  ** 二つ目の図形のモデル変換行列を求める
  */

  /* 図形を Z 軸中心に r-90 度回転する変換行列 */
  setRotationZ(rotation, r - 90.0);

  /*
  ** 二つ目の図形の座標変換と描画
  */

  /* 回転の変換行列にビューポート変換行列を掛ける */
  multiply(matrix, viewport, rotation);
  /* 画面上の点の位置を求める */
  project(screen, matrix, vertex, NVERTEX);
  /* 求めた画面上の点の位置を使ってワイヤーフレームで図形を描く */
  wireframe(screen, edge, NEDGE);
}
