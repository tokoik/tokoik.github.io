﻿/*
** OpenGL/GLUT を使って点を打つプログラム
** 図形を描く draw() を point() を使って作成し，
** それをこのプログラムとリンクする
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#if defined(WIN32)
#  pragma warning(disable:4819)
//#  pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#  include "glut.h"
#elif defined(X11)
#  include <GL/glut.h>
#elif defined(__APPLE__)
#  include <GLUT/glut.h>
#else
#  error "This platform is not supported."
#endif
#ifdef CGSAMPLE
#  define CGSIZEX 960
#  define CGSIZEY 720
#else
#  define CGSIZEX 320
#  define CGSIZEY 240
#endif

/*
** フレームバッファ
*/
typedef struct { GLubyte r, g, b, a; } Color;
static Color *framebuffer = NULL;
static Color clearcolor = { UCHAR_MAX, UCHAR_MAX, UCHAR_MAX, 0 };

/*
** 開いたウィンドウのサイズ
*/
static int width, height;

/*
** 操作を行ったキー
*/
static unsigned char keychar = 0;
static int specialchar = 0;

/*
** ユーザーによる初期設定
*/
extern void setup(void);

/*
** 与えられた領域を実際にレンダリングする関数
** point() を使って外部関数として定義する
** 引数 width, height は現在のウィンドウの幅と高さ
*/
extern void draw(int width, int height);

/*
** 引数 d を UCHAR_MAX 倍して unsigned char の範囲にクランプする
** point() で使用する
*/
static GLubyte clamp_ubyte(double d)
{
  return d < 0.0 ? 0 : d > 1.0 ? UCHAR_MAX : (GLubyte)(d * UCHAR_MAX + 0.5);
}

/*
** 点 (x, y) に色 c で点を打つ
** draw() で使用する
*/
void point(int x, int y, const double *c)
{
  if (x >= 0 && x < width && y >= 0 && y < height)
  {
    const int i = width * y + x;
    framebuffer[i].r = clamp_ubyte(c[0]);
    framebuffer[i].g = clamp_ubyte(c[1]);
    framebuffer[i].b = clamp_ubyte(c[2]);
    framebuffer[i].a = 255;
  }
}

/*
** 背景色を設定する
*/
void background(double r, double g, double b)
{
  clearcolor.r = clamp_ubyte(r);
  clearcolor.g = clamp_ubyte(g);
  clearcolor.b = clamp_ubyte(b);
  clearcolor.a = 0;
}

/*
** ウィンドウサイズを変更する
*/
void size(int width, int height)
{
  glutReshapeWindow(width, height);
}

/*
** 画面をクリアする
*/
void clear(void)
{
  const int n = width * height;
  for (int i = 0; i < n; ++i) framebuffer[i] = clearcolor;
}

/*
** 直前にタイプしたキーの文字を得る
*/
unsigned char getkey(void)
{
  return keychar;
}

/*
** 直前にタイプした矢印キー他の番号を得る
*/
int getspecial(void)
{
  return specialchar;
}

/*
** 経過時間をミリ秒で求める
*/
int elapsed(void)
{
  return glutGet(GLUT_ELAPSED_TIME);
}

/*
** draw() で作成された画像を表示する
*/
static void display(void)
{
  clear();
  draw(width, height);
  glDrawPixels(width, height, GL_RGBA, GL_UNSIGNED_BYTE, framebuffer);
  glutSwapBuffers();
}

/*
** メモリが獲得できたかチェックする
*/
static void check(const void *memory)
{
  if (memory == NULL)
  {
    fputs("Insufficient memory\n", stderr);
    exit(1);
  }
}

/*
** ウィンドウの幅と高さを得てウィンドウの座標系とビューポートを一致させる
*/
static void resize(int w, int h)
{
  framebuffer = (Color *)realloc(framebuffer, w * h * sizeof(Color));
  check(framebuffer);

  glViewport(0, 0, width = w, height = h);
  glLoadIdentity();
  glOrtho(-0.5, (GLdouble)w - 0.5, -0.5, (GLdouble)h - 0.5, -1.0, 1.0);
}

/*
** タイプした文字を記録して q, Q, ESC なら終了する
*/
static void keyboard(unsigned char key, int x, int y)
{
  switch (key)
  {
  case 'q':
  case 'Q':
  case '\033':
    exit(0);
  default:
    keychar = key;
    break;
  }
}

/*
** キーを離したら覚えていた文字を忘れる
*/
static void keyboardUp(unsigned char key, int x, int y)
{
  keychar = 0;
}

/*
** タイプしたファンクションキーを記録する
*/
static void special(int key, int x, int y)
{
  specialchar = key;
}

/*
** ファンクションキーを離したら覚えていたファンクションキーを忘れる
*/
static void specialUp(int key, int x, int y)
{
  specialchar = 0;
}

/*
** アニメーション
*/
static void idle(void)
{
  glutPostRedisplay();
}

/*
** 初期化
*/
static void init(void)
{
  glRasterPos2i(-1, -1);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
  setup();
}

/*
** glut/OpenGL の初期化と実行
*/
int main(int argc, char *argv[])
{
  framebuffer = (Color *)malloc(CGSIZEX * CGSIZEY * sizeof(Color));
  check(framebuffer);

  glutInit(&argc, argv);
  glutInitWindowSize(CGSIZEX, CGSIZEY);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  glutCreateWindow("CG sample");
  glutDisplayFunc(display);
  glutReshapeFunc(resize);
  glutKeyboardFunc(keyboard);
  glutKeyboardUpFunc(keyboardUp);
  glutSpecialFunc(special);
  glutSpecialUpFunc(specialUp);
  glutIdleFunc(idle);
  init();
  glutGet(GLUT_ELAPSED_TIME);
  glutMainLoop();
  return 0;
}
