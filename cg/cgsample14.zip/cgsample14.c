﻿/* 数学ライブラリは多分使うと思う */
#include <math.h>

/* int 型の最大値 INT_MAX は limits.h の中で定義されている */
#include <limits.h>

/* (x, y) に色 c で点を打つ関数 (他で定義している) */
extern void point(int, int, const double *);

/* ウィンドウサイズを変更する (他で定義している) */
extern void size(int, int);

/* 背景色 (デフォルトは白) を変更する (他で定義している) */
extern void background(double, double, double);

/* 画面を消去する (他で定義している) */
extern void clear(void);

/* 直前にタイプしたキーの文字を得る (他で定義している) */
extern unsigned char getkey(void);

/* ←:100 ↑:101 →:102 ↓:103 を返す (他で定義している) */
extern int getspecial(void);

/* 経過時間を ms で返す (他で定義している) */
extern int elapsed(void);

/* 描画前の初期設定 */
void setup(void)
{
  /*
  ** ここは最初に draw() を実行する前に一度だけ実行される
  ** 背景色の変更など描画前に行いたい処理があればここに書く
  */
}

/* 光源 */
static double lpos[]  = { 3.0, 5.0, -2.0 };   /* 光源位置　　　　　　　 */
static double ldiff[] = { 1.0, 1.0, 1.0 };    /* 光源強度の拡散反射成分 */
static double lspec[] = { 1.0, 1.0, 1.0 };    /* 光源強度の鏡面反射成分 */
static double lamb[]  = { 0.4, 0.4, 0.4 };    /* 環境光強度　　　　　　 */

/* 材質 */
static double kamb[]  = { 0.4, 0.0, 0.0 };    /* 環境光反射率　　　　　 */
static double kdiff[] = { 0.4, 0.0, 0.0 };    /* 拡散反射率　　　　　　 */
static double kspec[] = { 0.4, 0.4, 0.4 };    /* 鏡面反射率　　　　　　 */
static double kshi    = 60.0;                 /* 輝き係数　　　　　　　 */

/* 球のデータ */
static double center[] = { 0.0, 0.0, -4.0 };  /* 球の中心位置　　　　　 */
static double radius = 1.0;                   /* 球の半径　　　　　　　 */

/* 視点の位置 */
static double e[] = { 0.0, 0.0, 0.0 };

/* 視点とスクリーンの距離 */
static const double h = 1.0;

/* 図形を描く */
void draw(int width, int height)
{
  /* 画面上の画素の位置 */
  int xi, yi;

  /* 画面上のすべての画素について */
  for (yi = 0; yi < height; ++yi)
  {
    for (xi = 0; xi < width; ++xi)
    {
      /* 求める画素の色 */
      double c[3] = { 0.3, 0.4, 0.5 };

      /* スクリーン上の位置 */
      double xs = (double)(xi * 2 - width) / (double)height;
      double ys = (double)(yi * 2 - height) / (double)height;

      /*
      ** 上の配列変数 c に値を設定するプログラムをこの部分に作成してください
      */

      /* 画面上の画素に色を付ける */
      point(xi, yi, c);
    }
  }
}
