﻿/* 数学ライブラリは多分使うと思う */
#include <math.h>

/* int 型の最大値 INT_MAX は limits.h の中で定義されている */
#include <limits.h>

/* (x, y) に色 c で点を打つ関数 (他で定義している) */
extern void point(int, int, const double *);

/* ウィンドウサイズを変更する (他で定義している) */
extern void size(int, int);

/* 背景色 (デフォルトは白) を変更する (他で定義している) */
extern void background(double, double, double);

/* 画面を消去する (他で定義している) */
extern void clear(void);

/* 直前にタイプしたキーの文字を得る (他で定義している) */
extern unsigned char getkey(void);

/* ←:100 ↑:101 →:102 ↓:103 を返す (他で定義している) */
extern int getspecial(void);

/* 経過時間を ms で返す (他で定義している) */
extern int elapsed(void);

/* 描画前の初期設定 */
void setup(void)
{
  /*
  ** ここは最初に draw() を実行する前に一度だけ実行される
  ** 背景色の変更など描画前に行いたい処理があればここに書く
  */
}

/* デプスバッファ */
#  define DWIDTH 2048          /* ディスプレイの横方向の画素数 */
#  define DHEIGHT 2048         /* ディスプレイの縦方向の画素数 */
static int dbuffer[DHEIGHT][DWIDTH];    /* 本当は unsigned int */

/*
** デプスバッファのクリア
*/
static void zClear(int width, int height)
{
  /*
  ** dbuffer の width×height の範囲に INT_MAX を代入する処理を実装する
  */
  int x, y;

  for (y = 0; y < height; ++y)
  {
    for (x = 0; x < width; ++x)
    {
      dbuffer[y][x] = INT_MAX;
    }
  }
}

/*
** (x0, y, z0), (x1, y, z1) を結ぶ線を引く
*/
static void hline3D(int x0, int z0, int x1, int z1, int y, const double *c)
{
  int dx = x1 - x0;

  if (dx < 0)
  {
    int t;

    dx = -dx;
    t = x0; x0 = x1; x1 = t;
    t = z0; z0 = z1; z1 = t;
  }

  if (dx > 0)
  {
    int x = x0;
    /*
    ** x を 1 増したときの z の増分を求めるための準備の処理を実装する
    */
    int dz = z1 - z0;
    int mz = ((dz >= 0) ? dz : dz - dx + 1) / dx;
    int az = (mz * dx - dz) << 1;
    int bz = dx << 1;
    int ez = dx;
    int z = z0;

    for (;;)
    {
      /*
      ** z 値がこの画素におけるデプスバッファの値 dbuffer[y][x]
      ** より小さい時だけ点を描き, その時の z 値を dbuffer[y][x]
      ** に代入するよう下の１行を書き換える
      */
      //point(x, y, c);
      if (z < dbuffer[y][x])
      {
        point(x, y, c);
        dbuffer[y][x] = z;
      }

      if (++x > x1) break;

      /*
      ** x を 1 増したときの z の値を求める
      */
      z += mz;
      if ((ez += az) <= 0)
      {
        ez += bz;
        ++z;
      }
    }
  }
}

/*
** (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) を頂点とする三角形を色 c で描く
*/
static void triangle3D(
  int x0, int y0, int z0,
  int x1, int y1, int z1,
  int x2, int y2, int z2,
  const double *c)
{
  int y, dy1, dy2;

  /* ３頂点の並べ替え (y0 < y1 < y2) */
  if (y1 < y0)
  {
    int t;
    t = x0; x0 = x1; x1 = t;
    t = y0; y0 = y1; y1 = t;
    t = z0; z0 = z1; z1 = t;
  }
  if (y2 < y0)
  {
    int t;
    t = x0; x0 = x2; x2 = t;
    t = y0; y0 = y2; y2 = t;
    t = z0; z0 = z2; z2 = t;
  }
  if (y2 < y1)
  {
    int t;
    t = x1; x1 = x2; x2 = t;
    t = y1; y1 = y2; y2 = t;
    t = z1; z1 = z2; z2 = t;
  }

  y = y0;

  /* 長編側 */
  if ((dy2 = y2 - y0) > 0)
  {
    int hx2 = x0;
    int dx2 = x2 - x0;
    int mx2 = ((dx2 >= 0) ? dx2 : dx2 - dy2 + 1) / dy2;
    int ax2 = (mx2 * dy2 - dx2) << 1;
    int bx2 = dy2 << 1;
    int ex2 = dy2;

    int hz2 = z0;
    int dz2 = z2 - z0;
    int mz2 = ((dz2 >= 0) ? dz2 : dz2 - dy2 + 1) / dy2;
    int az2 = (mz2 * dy2 - dz2) << 1;
    int bz2 = dy2 << 1;
    int ez2 = dy2;

    /* 短辺の上半分 */
    if ((dy1 = y1 - y0) > 0)
    {
      int hx1 = x0;
      int dx1 = x1 - x0;
      int mx1 = ((dx1 >= 0) ? dx1 : dx1 - dy1 + 1) / dy1;
      int ax1 = (mx1 * dy1 - dx1) << 1;
      int bx1 = dy1 << 1;
      int ex1 = dy1;

      int hz1 = z0;
      int dz1 = z1 - z0;
      int mz1 = ((dz1 >= 0) ? dz1 : dz1 - dy1 + 1) / dy1;
      int az1 = (mz1 * dy1 - dz1) << 1;
      int bz1 = dy1 << 1;
      int ez1 = dy1;

      do
      {
        /* 水平線出力 */
        hline3D(hx1, hz1, hx2, hz2, y++, c);

        hx2 += mx2;
        if ((ex2 += ax2) <= 0)
        {
          ex2 += bx2;
          ++hx2;
        }

        hx1 += mx1;
        if ((ex1 += ax1) <= 0)
        {
          ex1 += bx1;
          ++hx1;
        }

        hz2 += mz2;
        if ((ez2 += az2) <= 0)
        {
          ez2 += bz2;
          ++hz2;
        }

        hz1 += mz1;
        if ((ez1 += az1) <= 0)
        {
          ez1 += bz1;
          ++hz1;
        }
      }
      while (--dy1 > 0);
    }

    /* 短辺の下半分 */
    if ((dy1 = y2 - y1) > 0)
    {
      int hx1 = x1;
      int dx1 = x2 - x1;
      int mx1 = ((dx1 >= 0) ? dx1 : dx1 - dy1 + 1) / dy1;
      int ax1 = (mx1 * dy1 - dx1) << 1;
      int bx1 = dy1 << 1;
      int ex1 = dy1;

      int hz1 = z1;
      int dz1 = z2 - z1;
      int mz1 = ((dz1 >= 0) ? dz1 : dz1 - dy1 + 1) / dy1;
      int az1 = (mz1 * dy1 - dz1) << 1;
      int bz1 = dy1 << 1;
      int ez1 = dy1;

      do
      {
        /* 水平線出力 */
        hline3D(hx1, hz1, hx2, hz2, y++, c);

        hx2 += mx2;
        if ((ex2 += ax2) <= 0)
        {
          ex2 += bx2;
          ++hx2;
        }

        hx1 += mx1;
        if ((ex1 += ax1) <= 0)
        {
          ex1 += bx1;
          ++hx1;
        }

        hz2 += mz2;
        if ((ez2 += az2) <= 0)
        {
          ez2 += bz2;
          ++hz2;
        }

        hz1 += mz1;
        if ((ez1 += az1) <= 0)
        {
          ez1 += bz1;
          ++hz1;
        }
      }
      while (--dy1 > 0);
    }
  }
}

/*
** 座標変換：ベクトル v2 ← ベクトル v1 に行列 m を掛けた結果
*/
static void transform(double v2[], double m[][4], double v1[])
{
  int j;

  for (j = 0; j < 4; ++j)
  {
    v2[j] = m[j][0] * v1[0]
          + m[j][1] * v1[1]
          + m[j][2] * v1[2]
          + m[j][3] * v1[3];
  }
}

/*
** 行列の積：行列 m3 ← 行列 m1 と行列 m2 の積
*/
static void multiply(double m3[][4], double m1[][4], double m2[][4])
{
  int k;

  for (k = 0; k < 4; ++k)
  {
    int j;

    for (j = 0; j < 4; ++j)
    {
      m3[k][j] = m1[k][0] * m2[0][j]
               + m1[k][1] * m2[1][j]
               + m1[k][2] * m2[2][j]
               + m1[k][3] * m2[3][j];
    }
  }
}

/*
** 平行移動：行列 m ← (x, y, z) に平行移動する変換行列
*/
static void setTranslation(double m[][4], double x, double y, double z)
{
  /*
  ** ４×４要素の配列 m の個々の要素に値を設定するプログラムを書く
  */
  m[0][0] = 1.0;  m[0][1] = 0.0;  m[0][2] = 0.0;  m[0][3] = x;
  m[1][0] = 0.0;  m[1][1] = 1.0;  m[1][2] = 0.0;  m[1][3] = y;
  m[2][0] = 0.0;  m[2][1] = 0.0;  m[2][2] = 1.0;  m[2][3] = z;
  m[3][0] = 0.0;  m[3][1] = 0.0;  m[3][2] = 0.0;  m[3][3] = 1.0;
}

/*
** 拡大縮小：行列 m ← 原点中心に (a, b, c) 倍する変換行列
*/
static void setScale(double m[][4], double a, double b, double c)
{
  /*
  ** ４×４要素の配列 m の個々の要素に値を設定するプログラムを書く
  */
  m[0][0] = a;    m[0][1] = 0.0;  m[0][2] = 0.0;  m[0][3] = 0.0;
  m[1][0] = 0.0;  m[1][1] = b;    m[1][2] = 0.0;  m[1][3] = 0.0;
  m[2][0] = 0.0;  m[2][1] = 0.0;  m[2][2] = c;    m[2][3] = 0.0;
  m[3][0] = 0.0;  m[3][1] = 0.0;  m[3][2] = 0.0;  m[3][3] = 1.0;
}

#define PI 3.14159265358979323846                       /* 円周率π */

/*
** x 軸中心の回転：行列 m ← x 軸を中心にして angle 度回転する変換行列
*/
static void setRotationX(double m[][4], double angle)
{
  /*
  ** ４×４要素の配列 m の個々の要素に X 軸中心の回転行列の値を設定する
  */
  double rad = angle * PI / 180.0;
  double c = cos(rad);
  double s = sin(rad);

  m[0][0] = 1.0;  m[0][1] = 0.0;  m[0][2] = 0.0;  m[0][3] = 0.0;
  m[1][0] = 0.0;  m[1][1] = c;    m[1][2] = -s;   m[1][3] = 0.0;
  m[2][0] = 0.0;  m[2][1] = s;    m[2][2] = c;    m[2][3] = 0.0;
  m[3][0] = 0.0;  m[3][1] = 0.0;  m[3][2] = 0.0;  m[3][3] = 1.0;
}

/*
** y 軸中心の回転：行列 m ← y 軸を中心にして angle 度回転する変換行列
*/
static void setRotationY(double m[][4], double angle)
{
  /*
  ** ４×４要素の配列 m の個々の要素に Y 軸中心の回転行列の値を設定する
  */
  double rad = angle * PI / 180.0;
  double c = cos(rad);
  double s = sin(rad);

  m[0][0] = c;    m[0][1] = 0.0;  m[0][2] = s;    m[0][3] = 0.0;
  m[1][0] = 0.0;  m[1][1] = 1.0;  m[1][2] = 0.0;  m[1][3] = 0.0;
  m[2][0] = -s;   m[2][1] = 0.0;  m[2][2] = c;    m[2][3] = 0.0;
  m[3][0] = 0.0;  m[3][1] = 0.0;  m[3][2] = 0.0;  m[3][3] = 1.0;
}

/*
** z 軸中心の回転：行列 m ← z 軸を中心にして angle 度回転する変換行列
*/
static void setRotationZ(double m[][4], double angle)
{
  /*
  ** ４×４要素の配列 m の個々の要素に Z 軸中心の回転行列の値を設定する
  */
  double rad = angle * PI / 180.0;
  double c = cos(rad);
  double s = sin(rad);

  m[0][0] = c;    m[0][1] = -s;   m[0][2] = 0.0;  m[0][3] = 0.0;
  m[1][0] = s;    m[1][1] = c;    m[1][2] = 0.0;  m[1][3] = 0.0;
  m[2][0] = 0.0;  m[2][1] = 0.0;  m[2][2] = 1.0;  m[2][3] = 0.0;
  m[3][0] = 0.0;  m[3][1] = 0.0;  m[3][2] = 0.0;  m[3][3] = 1.0;
}

/*
** 任意軸中心の回転
**     ベクトル (x, y, z) を中心に angle 度回転する
**     変換行列を r に設定する
*/
static void setRotation(double r[][4], double x, double y, double z, double angle)
{
  /*
  ** Step 1. (x, y, z) を方向余弦（単位行列）に変換する
  ** Step 2. angle の単位を radian に変換する
  ** Step 3. ４×４要素の配列 m の個々の要素に方向余弦中心の回転行列の値を設定する
  */
  double a = sqrt(x * x + y * y + z * z);

  if (a != 0.0)
  {
    double l  = x / a, m  = y / a, n  = z / a;
    double l2 = l * l, m2 = m * m, n2 = n * n;
    double lm = l * m, mn = m * n, nl = n * l;

    double rad = angle * PI / 180.0;
    double c = cos(rad), c1 = 1.0 - c;
    double s = sin(rad);

    r[0][0] = (1.0 - l2) * c + l2;
    r[0][1] = lm * c1 - n * s;
    r[0][2] = nl * c1 + m * s;
    r[0][3] = 0.0;

    r[1][0] = lm * c1 + n * s;
    r[1][1] = (1.0 - m2) * c + m2;
    r[1][2] = mn * c1 - l * s;
    r[1][3] = 0.0;

    r[2][0] = nl * c1 - m * s;
    r[2][1] = mn * c1 + l * s;
    r[2][2] = (1.0 - n2) * c + n2;
    r[2][3] = 0.0;

    r[3][0] = 0.0;
    r[3][1] = 0.0;
    r[3][2] = 0.0;
    r[3][3] = 1.0;
  }
}

/*
** 透視変換
**     画角 fovy°で投影を行なう透視変換行列を m に設定する
*/
static void setPerspective(double m[][4], double fovy, double aspect, double zNear, double zFar)
{
  /*
  ** zNear の位置にある前方面と zFar の位置にある後方面の間の空間にある図形を
  ** 画角 fovy°で前方面の位置にあるスクリーンに投影する変換行列を m に求める
  ** 画面の縦横比は aspect とする
  */
  double dz = zFar - zNear;

  if (dz != 0.0)
  {
    double f = 1.0f / tan(fovy * PI / 180.0 * 0.5);

    m[0][0] = f / aspect;
    m[1][1] = f;
    m[2][2] = -(zFar + zNear) / dz;
    m[2][3] = -2.0 * zFar * zNear / dz;
    m[3][2] = -1.0;
    m[0][1] = m[0][2] = m[0][3] =
    m[1][0] = m[1][2] = m[1][3] =
    m[2][0] = m[2][1] =
    m[3][0] = m[3][1] =
    m[3][3] = 0.0;
  }
}

/*
** ビュー変換
**     視点 (ex, ey, ez) から目標点 (tx, ty, tz) を上方向を (ux, uy, uz) として
**     見る変換行列を m に設定する
*/
static void lookAt(double m[][4],
  double ex, double ey, double ez,
  double tx, double ty, double tz,
  double ux, double uy, double uz
  )
{
  /*
  ** Step 1. 視点の位置と逆方向に平行移動する変換行列を求める
  ** Step 2. 視点と目標点の位置から求まる視線の回転行列を求める
  ** Step 3. これらを掛けて、結果を m に格納する
  */
  double l;

  // z 軸 = e - t
  tx = ex - tx;
  ty = ey - ty;
  tz = ez - tz;
  l = sqrt(tx * tx + ty * ty + tz * tz);
  if (l == 0.0) return;
  m[2][0] = tx / l;
  m[2][1] = ty / l;
  m[2][2] = tz / l;

  // x 軸 = u x z 軸
  tx = uy * m[2][2] - uz * m[2][1];
  ty = uz * m[2][0] - ux * m[2][2];
  tz = ux * m[2][1] - uy * m[2][0];
  l = sqrt(tx * tx + ty * ty + tz * tz);
  if (l == 0.0) return;
  m[0][0] = tx / l;
  m[0][1] = ty / l;
  m[0][2] = tz / l;

  // y 軸 = z 軸 x x 軸
  m[1][0] = m[2][1] * m[0][2] - m[2][2] * m[0][1];
  m[1][1] = m[2][2] * m[0][0] - m[2][0] * m[0][2];
  m[1][2] = m[2][0] * m[0][1] - m[2][1] * m[0][0];

  // 平行移動
  m[0][3] = -(ex * m[0][0] + ey * m[0][1] + ez * m[0][2]);
  m[1][3] = -(ex * m[1][0] + ey * m[1][1] + ez * m[1][2]);
  m[2][3] = -(ex * m[2][0] + ey * m[2][1] + ez * m[2][2]);

  // 残り
  m[3][0] = m[3][1] = m[3][2] = 0.0;
  m[3][3] = 1.0;
}

/*
** 投影によって画面上の座標値を求める
**     v: 座標値の配列（頂点表）, m: 変換行列
**     s: 画面上の座標値の配列, n: 座標数（頂点数）
*/
static void projection(double t[][4], double m[][4], double v[][4], int n)
{
  /*
  ** 引数 v で与えられた n 個の４要素の配列（２次元配列）の
  ** 個々の要素を引数 m で与えられた４×４要素の配列（変換行列）
  ** で座標変換し，引数 t で与えられた配列の各要素に格納する
  */
  int i;

  for (i = 0; i < n; ++i) transform(t[i], m, v[i]);
}

/*
** 陰影付け
**     法線を n, 光源の方向を l としたときの反射光強度を引数 itot に求める
*/
static void shading(double itot[3], /* 反射光強度 Itot  */
  double n[3],        /* 法線方向　　　　　　　　 N     */
  double l[3],        /* 光線方向　　　　　　　　 L     */ 
  double ldiff[3],    /* 光源強度の拡散反射光成分 Ldiff */
  double lspec[3],    /* 光源強度の鏡面反射光成分 Lspec */
  double lamb[3],     /* 環境光強度　　　　　　　 Lamb  */
  double kdiff[3],    /* 拡散反射係数　　　　　　 Kdiff */
  double kspec[3],    /* 鏡面反射係数　　　　　　 Kspec */
  double kshi,        /* 輝き係数　　　　　　　　 Kshi  */
  double kamb[3]      /* 環境光に対する反射係数　 Kamb  */
  )
{
  double rdiff, rspec, r[3];
  double idiff[3], ispec[3], iamb[3];

  /*
  ** (1) rdiff に法線 N と光源方向 L の内積を求めなさい
  */

  /*
  ** (2) r に法線 N の面に L の方向から到来する入射光の正反射方向
  **     R を求めなさい
  */

  /*
  ** (3) 視点方向 V を (0, 0, 1) として，入射光の正反射方向 R と
  **     視点方向 V との内積を rspec に求めなさい
  */

  /*
  ** (4) rdiff が負なら rdiff を 0 にしなさい → max(N・L, 0)
  */

  /*
  ** (5) rspec が負なら rspec を 0 にしなさい → max(R・V, 0)
  **     その後 rspec を kshi 乗して rspec に格納しなさい
  **     C 言語ではべき乗に数学関数 pow() を使う
  */

  /*
  ** (6) 拡散反射光強度 Idiff を idiff に求めなさい
  */

  /*
  ** (7) 鏡面反射光強度 Ispec を ispec に求めなさい
  */

  /*
  ** (8) 環境光の反射光強度 Iamb を iamb に求めなさい
  */

  /*
  ** (9) Idiff, Ispec, Iamb をもとに，この三角形 i の反射光
  **     強度 Itot を求め，引数 itot に格納しなさい
  **     以下を書き換えなさい
  */
  itot[0] = kdiff[0];
  itot[1] = kdiff[1];
  itot[2] = kdiff[2];
}

/*
** フラットシェーディング（三角形ごとに陰影を計算）
**     頂点データが v, 面データが f で与えられる nf 枚の三角形の
**     個々の陰影を計算して引数 color に格納する
**     ・拡散反射係数 kdiff と環境光に対する反射係数 kamb は三角
**       形の色として三角形ごとに与えられるものとする
**     ・鏡面反射係数 kspec と 輝き係数 kshiはすべての三角形で同
**       じ値を用いるものとする
*/
static void flatshading(double color[][3], /* 三角形の色 */
  double l[3],        /* 光線方向　　　　　　　　 L     */ 
  double ldiff[3],    /* 光源強度の拡散反射光成分 Ldiff */
  double lspec[3],    /* 光源強度の鏡面反射光成分 Lspec */
  double lamb[3],     /* 環境光強度　　　　　　　 Lamb  */
  double kdiff[][3],  /* 面ごとの拡散反射係数　　 Kdiff */
  double kspec[3],    /* 鏡面反射係数　　　　　　 Kspec */
  double kshi,        /* 輝き係数　　　　　　　　 Kshi  */
  double kamb[][3],   /* 環境光に対する反射係数　 Kamb  */
  double v[][4],      /* 頂点の視点座標における座標値　 */
  int f[][3],         /* 三角形の頂点番号　　　　　　　 */
  int nf              /* 三角形の数　　　　　　　　　   */
  )
{
  int i;

  for (i = 0; i < nf; ++i)
  {
    /* 三角形の頂点の番号を取り出す */
    int p0 = f[i][0], p1 = f[i][1], p2 = f[i][2];
    /* ２辺ののベクトル v1 = w0p1 - w1p0 と v2 = w0p2 - w2p0 を求める */
    double v1x = v[p0][3] * v[p1][0] - v[p1][3] * v[p0][0];
    double v1y = v[p0][3] * v[p1][1] - v[p1][3] * v[p0][1];
    double v1z = v[p0][3] * v[p1][2] - v[p1][3] * v[p0][2];
    double v2x = v[p0][3] * v[p2][0] - v[p2][3] * v[p0][0];
    double v2y = v[p0][3] * v[p2][1] - v[p2][3] * v[p0][1];
    double v2z = v[p0][3] * v[p2][2] - v[p2][3] * v[p0][2];
    /* v1 と v2 の外積により法線ベクトル N を求める */
    double n[3] = {
      v1y * v2z - v1z * v2y,
      v1z * v2x - v1x * v2z,
      v1x * v2y - v1y * v2x,
    };
    /* n の長さを求める */
    double a = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);

    if (a > 0.0)
    {
      /* 法線ベクトルを正規化する */
      n[0] /= a;
      n[1] /= a;
      n[2] /= a;

      /* i 番目の三角形の陰影を求める */
      shading(color[i], n, l, ldiff, lspec, lamb, kdiff[i], kspec, kshi, kamb[i]);
    }
  }
}

/*
** 表面形状の描画（三角形表 f の面を s に与えられた座標値で描画）
**     vp: ビューポート変換行列
**     s: クリッピング座標値, f: 三角形表, nf: 面数
*/
static void surface(double vp[4][4], double s[][4], double c[][3], int f[][3], int nf)
{
  int i;

  for (i = 0; i < nf; ++i)
  {
    /* 三角形の頂点の番号を取り出す */
    int v0 = f[i][0],  v1 = f[i][1],  v2 = f[i][2];
    /* 頂点の実座標を求めて整数化する */
    int x0 = (int)(s[v0][0] * vp[0][0] / s[v0][3] + vp[0][3] + 0.5);
    int y0 = (int)(s[v0][1] * vp[1][1] / s[v0][3] + vp[1][3] + 0.5);
    int z0 = (int)(s[v0][2] * vp[2][2] / s[v0][3] + vp[2][3] + 0.5);
    int x1 = (int)(s[v1][0] * vp[0][0] / s[v1][3] + vp[0][3] + 0.5);
    int y1 = (int)(s[v1][1] * vp[1][1] / s[v1][3] + vp[1][3] + 0.5);
    int z1 = (int)(s[v1][2] * vp[2][2] / s[v1][3] + vp[2][3] + 0.5);
    int x2 = (int)(s[v2][0] * vp[0][0] / s[v2][3] + vp[0][3] + 0.5);
    int y2 = (int)(s[v2][1] * vp[1][1] / s[v2][3] + vp[1][3] + 0.5);
    int z2 = (int)(s[v2][2] * vp[2][2] / s[v2][3] + vp[2][3] + 0.5);
    /* 背面ポリゴンの除去 */
    int dx1 = x1 - x0, dy1 = y1 - y0;
    int dx2 = x2 - x0, dy2 = y2 - y0;
    int d = dx1 * dy2 - dx2 * dy1;

    if (d > 0) triangle3D(x0, y0, z0, x1, y1, z1, x2, y2, z2, c[i]);
  }
}

/* 頂点の座標値（頂点表のデータ） */
static double vertex[][4] =
{
  /*
  ** 頂点表のデータ (同次座標) をここに書く
  */
  { -4.0,  4.0,  2.0,  1.0 }, /* 頂点 a */
  {  4.0,  4.0,  2.0,  1.0 }, /* 頂点 b */
  {  3.0,  3.0,  0.0,  1.0 }, /* 頂点 c */
  {  4.0,  4.0, -2.0,  1.0 }, /* 頂点 d */
  { -4.0,  4.0, -2.0,  1.0 }, /* 頂点 e */
  { -3.0,  3.0,  0.0,  1.0 }, /* 頂点 f */
  {  0.0,  0.0,  0.0,  1.0 }, /* 頂点 g */
};

/* 三角形の頂点番号（三角形表のデータ） */
static int face[][3] =
{
  /*
  ** 三角形表のデータをここに書く
  */
  { 6, 1, 0 },
  { 6, 2, 1 },
  { 6, 3, 2 },
  { 6, 4, 3 },
  { 6, 5, 4 },
  { 6, 0, 5 },
  { 0, 1, 5 },
  { 1, 2, 5 },
  { 5, 2, 4 },
  { 2, 3, 4 },
};

/* 三角形の色 */
static double color[][3] =
{
  /*
  ** 各三角形の色データをここに書く
  */
  { 0.0, 0.0, 1.0 },
  { 0.0, 1.0, 0.0 },
  { 0.0, 1.0, 1.0 },
  { 1.0, 0.0, 0.0 },
  { 1.0, 0.0, 1.0 },
  { 1.0, 1.0, 0.0 },
  { 0.7, 0.0, 0.3 },
  { 0.3, 0.7, 0.0 },
  { 0.0, 0.3, 0.7 },
  { 0.3, 0.0, 0.7 },
};

#define NVERTEX (sizeof vertex / sizeof vertex[0])      /* 頂点の数 */
#define NFACE (sizeof face / sizeof face[0])          /* 三角形の数 */

/* 視点座標 */
static double viewing[NVERTEX][4];

/* クリッピング座標 */
static double clipping[NVERTEX][4];

/* 三角形の陰影 */
static double fcolor[NFACE][3];

/* 光源 */
static double ldir[] =                        /* 方向　　　　　　　 */
{
  0.42426406871192851464,
  0.56568542494923801952,
  0.70710678118654752440,
  0.0
};
static double ldiff[] = { 1.0, 1.0, 1.0 };    /* 拡散反射成分の強度 */
static double lspec[] = { 1.0, 1.0, 1.0 };    /* 鏡面反射成分の強度 */
static double lamb[] = { 0.2, 0.2, 0.2 };     /* 環境光強度　　　　 */

/*
** 材質
*/
static double kspec[] = { 1.0, 1.0, 1.0 };    /* 鏡面反射係数　　　 */
static double kshi = 30.0;                    /* 輝き係数　　　　　 */

/*
** 図形の描画
*/
void draw(int width, int height)
{
  double rotation[4][4];                    /* 物体の回転の変換行列 */
  double spin[4][4];                        /* スピン用の変換行列　 */
  double model[4][4];                       /* モデル変換行列　　　 */
  double view[4][4];                        /* ビュー変換行列　　　 */
  double modelview[4][4];                   /* モデルビュー変換行列 */
  double perspective[4][4];                 /* 透視投影変換行列　　 */
  double scale[4][4];                       /* 拡大縮小の変換行列　 */
  double translation[4][4];                 /* 平行移動の変換行列　 */
  double viewport[4][4];                    /* ビューポート変換行列 */

	/* 図形を回転させるための回転角 */
	const double r = (elapsed() % 6000) * 0.06;

  /*
  ** Z バッファのクリア
  */
  zClear(width, height);

  /*
  ** ビューポート変換行列を求める
  */

  /* scale にウィンドウサイズにあわせて図形を拡大縮小する変換行列を求める */
  setScale(scale, (double)width * 0.5, (double)height * 0.5, (double)INT_MAX * 0.5);
  /* translation に図形がウィンドウに収まるように平行移動する変換行列を求める */
  setTranslation(translation, (double)width * 0.5, (double)height * 0.5, (double)INT_MAX * 0.5);
  /* 拡大縮小の変換行列に平行移動の変換行列を掛けてビューポート変換行列を求める */
  multiply(viewport, translation, scale);

  /*
  ** (10) 必要に応じて以下を書き換える
  */

  /*
  ** ビュー変換行列を求める
  */
  lookAt(view, 0.0, 15.0, 20.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

  /*
  ** 透視投影変換行列を求める
  */
  setPerspective(perspective, 30.0, (double)width / (double)height, 5.0, 50.0);

  /*
  ** 回転アニメーション用の変換行列を求める
  */
  setRotationY(spin, r);                                  /* 回転角 */

  /*
  ** 一つ目の図形のモデル変換行列を求める
  */
  setRotationZ(rotation, 45.0);             /* Z 軸中心に 45°回転  */

  /*
  ** 一つ目の図形の座標変換と描画
  */
  multiply(model, spin, rotation);                    /* モデル変換 */
  multiply(modelview, view, model);                   /* ビュー変換 */
  projection(viewing, modelview, vertex, NVERTEX);      /* 視点座標 */
  flatshading(fcolor, ldir, ldiff, lspec, lamb, color, kspec, kshi, color, viewing, face, NFACE);
  projection(clipping, perspective, viewing, NVERTEX);      /* 投影 */
  surface(viewport, clipping, fcolor, face, NFACE);         /* 描画 */

  /*
  ** 二つ目の図形のモデル変換行列を求める
  */
  setRotationZ(rotation, -135.0);         /* Z 軸中心に -135°回転  */

  /*
  ** 二つ目の図形の座標変換と描画
  */
  multiply(model, spin, rotation);                    /* モデル変換 */
  multiply(modelview, view, model);                   /* ビュー変換 */
  projection(viewing, modelview, vertex, NVERTEX);      /* 視点座標 */
  flatshading(fcolor, ldir, ldiff, lspec, lamb, color, kspec, kshi, color, viewing, face, NFACE);
  projection(clipping, perspective, viewing, NVERTEX);      /* 投影 */
  surface(viewport, clipping, fcolor, face, NFACE);         /* 描画 */
}
