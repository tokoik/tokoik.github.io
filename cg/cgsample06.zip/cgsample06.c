﻿/* (x, y) に色 c で点を打つ関数 (他で定義している) */
extern void point(int x, int y, const double *c);

/* 線分を描く */
static void line(int x0, int y0, int x1, int y1, const double *c)
{
  /*
  ** (1) 以前作成した線分を描く関数 line() の中身をここに書く
  */
}

/* 頂点の座標値（頂点表のデータ） */
static double vertex[][3] =
{
  /*
  ** (3) 頂点表のデータをここに書く
  */
  {  0.0,  6.0,  2.0 }, /* 頂点 a */
  {  4.0,  2.0,  2.0 }, /* 頂点 b */
  { -4.0,  2.0,  2.0 }, /* 頂点 c */
  {  0.0,  6.0, -2.0 }, /* 頂点 d */
  {  4.0,  2.0, -2.0 }, /* 頂点 e */
  { -4.0,  2.0, -2.0 }, /* 頂点 f */
  {  0.0,  4.0,  0.0 }, /* 頂点 g */
};

/* 線分の端点番号（稜線表のデータ） */
static int edge[][2] =
{
  /*
  ** (4) 稜線表のデータをここに書く
  */
  { 0, 1 }, /* 稜線ア (a-b) */
  { 1, 2 }, /* 稜線イ (b-c) */
  { 2, 0 }, /* 稜線ウ (c-a) */
  { 5, 4 }, /* 稜線エ (f-e) */
  { 4, 3 }, /* 稜線オ (e-d) */
  { 3, 5 }, /* 稜線カ (d-f) */
  { 0, 6 }, /* 稜線キ (a-g) */
  { 1, 6 }, /* 稜線ク (b-g) */
  { 2, 6 }, /* 稜線ケ (c-g) */
  { 3, 6 }, /* 稜線コ (d-g) */
  { 4, 6 }, /* 稜線サ (e-g) */
  { 5, 6 }, /* 稜線シ (f-g) */
  { 1, 4 }, /* 稜線ス (b-e) */
  { 2, 5 }, /* 稜線セ (c-f) */
};

#define NVERTEX (sizeof vertex / sizeof vertex[0])      /* 頂点の数 */
#define NEDGE (sizeof edge / sizeof edge[0])            /* 稜線の数 */

/*
** 図形の描画
*/
void draw(int width, int height)
{
  static const double black[] = { 0.0, 0.0, 0.0 };      /* 線分の色 */
  double scale = height * 0.1;
  int cx = width / 2;
  int cy = height / 5;

  /*
  ** (2) 関数 line() を使ってワイヤーフレームモデルの図形を描く手続きをここに書く
  **     座標値は x, y とも scale 倍した後, x に cx, y に cy を足せば，表示図形が
  **     ウィンドウにうまく収まるはず
  */
}
