﻿/*
** OpenGL/GLUT を使って点を打つプログラム
** 図形を描く draw() を point() を使って作成し，
** それをこのプログラムとリンクする
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#if defined(WIN32)
#  pragma warning(disable:4819)
#  pragma warning(disable:4996)
//#  pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#  include "glut.h"
#elif defined(X11)
#  include <GL/glut.h>
#elif defined(__APPLE__)
#  include <GLUT/glut.h>
#else
#  error "This platform is not supported."
#endif
#include "glext.h"

#ifdef CGSAMPLE
#  define CGSIZEX 960
#  define CGSIZEY 720
#else
#  define CGSIZEX 320
#  define CGSIZEY 240
#endif

#ifndef IMAGE
#  define IMAGE "image.tga"
#endif

/*
** フレームバッファ
*/
typedef struct { unsigned char r, g, b, a; } Color;
static Color *framebuffer = NULL;
static Color clearcolor = { UCHAR_MAX, UCHAR_MAX, UCHAR_MAX, 0 };

/*
** テクスチャ
*/
static unsigned char *imagebuffer = NULL;
static unsigned int texwidth, texheight, texdepth;

/*
** 開いたウィンドウのサイズ
*/
static int width, height;

/*
** 操作を行ったキー
*/
static unsigned char keychar = 0;
static int specialchar = 0;

/*
** ユーザーによる初期設定
*/
extern void setup(void);

/*
** 与えられた領域を実際にレンダリングする関数
** point() を使って外部関数として定義する
** 引数 width, height は現在のウィンドウの幅と高さ
*/
extern void draw(int width, int height);

/*
** 引数 d を UCHAR_MAX 倍して unsigned char の範囲にクランプする
** point() で使用する
*/
static GLubyte clamp_ubyte(double d)
{
  return d < 0.0 ? 0 : d > 1.0 ? UCHAR_MAX : (GLubyte)(d * UCHAR_MAX + 0.5);
}

/*
** 点 (x, y) に色 c で点を打つ
** draw() で使用する
*/
void point(int x, int y, const double *c)
{
  if (x >= 0 && x < width && y >= 0 && y < height)
  {
    const int i = width * y + x;
    framebuffer[i].r = clamp_ubyte(c[0]);
    framebuffer[i].g = clamp_ubyte(c[1]);
    framebuffer[i].b = clamp_ubyte(c[2]);
    framebuffer[i].a = 255;
  }
}

/*
** ウィンドウサイズを変更する
*/
void size(int width, int height)
{
  glutReshapeWindow(width, height);
}

/*
** 背景色を設定する
*/
void background(double r, double g, double b)
{
  clearcolor.r = clamp_ubyte(r);
  clearcolor.g = clamp_ubyte(g);
  clearcolor.b = clamp_ubyte(b);
  clearcolor.a = 0;
}

/*
** 画面をクリアする
*/
void clear(void)
{
  const int n = width * height;
  for (int i = 0; i < n; ++i) framebuffer[i] = clearcolor;
}

/*
** 直前にタイプしたキーの文字を得る
*/
unsigned char getkey(void)
{
  return keychar;
}

/*
** 直前にタイプした矢印キー他の番号を得る
*/
int getspecial(void)
{
  return specialchar;
}

/*
** 経過時間をミリ秒で求める
*/
int elapsed(void)
{
  return glutGet(GLUT_ELAPSED_TIME);
}

/*
** テクスチャ座標 (x, y) のテクスチャをサンプリングして
** 引数 c に格納する
*/
void texture(double *tcol, double s, double t)
{
#ifdef IMAGE
  unsigned int i;

  /* s, t を [0, 1] にクランプする */
  if (s < 0.0)
    s = 0.0;
  else if (s > 1.0)
    s = 1.0;
  if (t < 0.0)
    t = 0.0;
  else if (t > 1.0)
    t = 1.0;

  /* 画素位置を求める */
  i = ((int)(t * (double)(texheight - 1) + 0.5) * texwidth
    + (int)(s * (double)(texwidth - 1) + 0.5)) * texdepth;

  /* 画素色を取り出す */
  tcol[0] = (double)imagebuffer[i + 2] * 0.00392156862745098;
  tcol[1] = (double)imagebuffer[i + 1] * 0.00392156862745098;
  tcol[2] = (double)imagebuffer[i + 0] * 0.00392156862745098;
#endif
}

/*
** draw() で作成された画像を表示する
*/
static void display(void)
{
  clear();
  draw(width, height);
  glDrawPixels(width, height, GL_RGBA, GL_UNSIGNED_BYTE, framebuffer);
  glutSwapBuffers();
}

/*
** ウィンドウの幅と高さを得てウィンドウの座標系とビューポートを一致させる
*/
static void resize(int w, int h)
{
  /* フレームバッファ用のメモリを確保する */
  free(framebuffer);
  framebuffer = (Color *)malloc(w * h * sizeof (Color));
  if (framebuffer == NULL)
  {
    fputs("Insufficient memory\n", stderr);
    exit(1);
  }

  /* OpenGL の初期設定を行う */
  glViewport(0, 0, width = w, height = h);
  glLoadIdentity();
  glOrtho(-0.5, (GLdouble)w - 0.5, -0.5, (GLdouble)h - 0.5, -1.0, 1.0);
}

/*
** タイプした文字を記録して q, Q, ESC なら終了する
*/
static void keyboard(unsigned char key, int x, int y)
{
  switch (key)
  {
  case 'q':
  case 'Q':
  case '\033':
    exit(0);
  default:
    keychar = key;
    break;
  }
}

/*
** キーを離したら覚えていた文字を忘れる
*/
static void keyboardUp(unsigned char key, int x, int y)
{
  keychar = 0;
}

/*
** タイプしたファンクションキーを記録する
*/
static void special(int key, int x, int y)
{
  specialchar = key;
}

/*
** ファンクションキーを離したら覚えていたファンクションキーを忘れる
*/
static void specialUp(int key, int x, int y)
{
  specialchar = 0;
}

/*
** アニメーション
*/
static void idle(void)
{
  glutPostRedisplay();
}

/*
** TGA ファイル (8/16/24/32bit) の読み込み
*/
unsigned char *loadTga(const char *name, unsigned int *width, unsigned int *height, unsigned int *depth)
{
  unsigned char header[18], *buffer;
  size_t size;
  FILE *fp;

  // ファイルを開く
  fp = fopen(name, "rb");
  if (fp == NULL)
  {
    // 開けなかった
    fprintf(stderr, "Warning: Can't open file: %s\n", name);
    return NULL;
  }

  // ヘッダの読み込み
  if (fread(header, sizeof header, 1, fp) != 1)
  {
    // ヘッダの読み込みに失敗した
    fprintf(stderr, "Warning: Can't read file header: %s\n", name);
    fclose(fp);
    return NULL;
  }

  // 幅と高さ
  *width = header[13] << 8 | header[12];
  *height = header[15] << 8 | header[14];

  // 深度
  *depth = header[16] / 8;

  // データサイズ
  size = *width * *height * *depth;

  // メモリの確保
  buffer = (unsigned char *)malloc(size);
  if (buffer == NULL)
  {
    // メモリが足らなかった
    fprintf(stderr, "Warning: Too large file: %s\n", name);
    fclose(fp);
    return NULL;
  }

  // データの読み込み
  if (header[2] & 8)
  {
    // RLE
    size_t p = 0;
    char c;
    while (fread(&c, 1, 1, fp) == 1)
    {
      if (c & 0x80)
      {
        // run-length packet
        char tmp[4];
        size_t count = (c & 0x7f) + 1, i, j;
        if (p + count * *depth > size) break;
        fread(tmp, *depth, 1, fp);
        for (i = 0; i < count; ++i)
        {
          for (j = 0; j < *depth;) buffer[p++] = tmp[j++];
        }
      }
      else
      {
        // raw packet
        size_t count = (c + 1) * *depth;
        if (p + count > size) break;
        fread(buffer + p, count, 1, fp);
        p += count;
      }
    }
  }
  else
  {
    // 非圧縮
    fread(buffer, size, 1, fp);
  }

  // 読み込みチェック
  if (ferror(fp))
  {
    // 読み込みに失敗した
    fprintf(stderr, "Warning: Can't read image data: %s\n", name);
  }

  // ファイルを閉じる
  fclose(fp);

  return buffer;
}

/*
** 後始末
*/
void cleanup(void)
{
  free(imagebuffer);
  free(framebuffer);
}

/*
** 初期化
*/
static void init(void)
{
#ifdef IMAGE
  /* メモリを確保してテクスチャの画像を読み込む */
  imagebuffer = (unsigned char *)loadTga(IMAGE, &texwidth, &texheight, &texdepth);
  if (imagebuffer == NULL) exit(1);
#endif

  /* 後始末を登録する */
  atexit(cleanup);

  /* glDrawPixels() の設定 */
  glRasterPos2i(-1, -1);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

  /* ユーザ独自の初期化処理 */
  setup();
}

/*
** glut/OpenGL の初期化と実行
*/
int main(int argc, char *argv[])
{
  glutInit(&argc, argv);
  glutInitWindowSize(CGSIZEX, CGSIZEY);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  glutCreateWindow("CG sample");
  glutDisplayFunc(display);
  glutReshapeFunc(resize);
  glutKeyboardFunc(keyboard);
  glutKeyboardUpFunc(keyboardUp);
  glutSpecialFunc(special);
  glutSpecialUpFunc(specialUp);
  glutIdleFunc(idle);
  init();
  glutGet(GLUT_ELAPSED_TIME);
  glutMainLoop();
  return 0;
}
